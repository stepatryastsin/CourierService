package org.example.basicAlgorithm;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BasicAlgorithmTest {

    @Test
    void random() {
        System.out.println(BasicAlgorithm.random(10));
    }
}