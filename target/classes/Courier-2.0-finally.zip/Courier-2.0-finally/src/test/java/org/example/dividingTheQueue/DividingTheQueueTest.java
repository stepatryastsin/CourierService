package org.example.dividingTheQueue;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DividingTheQueueTest {

    @Test
    void chopped() {

    }

    @Test
    void sizeTheOrder() {

    }
}