package org.example.Может_не_пригодиться.agentCourier;

import org.example.Может_не_пригодиться.ID.ID;
import org.example.abstractPerson.Person;
import org.example.point.Point;

public class AgentCourier extends Person {
    private ID id; //id непонятно как использовать
    private String name;
    private double speed;
    private double energy;
    private Point location;

    public AgentCourier() {}


}