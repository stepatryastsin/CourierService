package org.example.Может_не_пригодиться.collectionPoint;

import org.example.point.Point;

public class CollectionPoint {
    private int id;
    private Point collectionPoint;

    public int getId() {
        return id;
    }

    public Point getCollectionPoint() {
        return collectionPoint;
    }
}
