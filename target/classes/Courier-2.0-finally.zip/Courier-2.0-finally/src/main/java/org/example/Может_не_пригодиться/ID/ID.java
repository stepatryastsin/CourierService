package org.example.Может_не_пригодиться.ID;

import java.util.Locale;
import java.util.Objects;
import java.util.Random;
/**
 * Generate a random string.
 */
public interface  ID {



String nextString();
}
