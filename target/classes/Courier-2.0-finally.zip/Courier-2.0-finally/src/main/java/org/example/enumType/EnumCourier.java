package org.example.enumType;
/**
 * Типы курьеров : Пеший, На мотоцикле, На машине
 */
public enum EnumCourier {
    PEOPLE,
    BIKE,
    CAR
}
