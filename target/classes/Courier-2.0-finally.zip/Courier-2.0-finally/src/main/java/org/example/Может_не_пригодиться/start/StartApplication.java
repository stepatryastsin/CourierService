package org.example.Может_не_пригодиться.start;

import org.example.abstractOrder.Order;
import org.example.abstractPerson.Person;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class StartApplication {
    List<Person> allPeople;
    List<Order> allOrder;

    public StartApplication(List<Person> allPeople, List<Order> allOrder) {
        this.allPeople = allPeople;
        this.allOrder = allOrder;
    }

    public void startOfWork() {

    }

}
