package org.example.main;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static org.example.javaFX.StartApplication.application;


public class Main{

    public static void main(String[] args) {

    application();


    }

}