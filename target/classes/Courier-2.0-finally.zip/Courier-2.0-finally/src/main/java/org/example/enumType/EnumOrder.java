package org.example.enumType;
/**
 * Типы заказов : Легкий, Средний , Тяжелый
 */
public enum EnumOrder {
    LIGHT,
    MEDIUM,
    HARD
}