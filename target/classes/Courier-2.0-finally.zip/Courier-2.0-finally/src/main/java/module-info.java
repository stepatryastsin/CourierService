module org.example.javaFX {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires maven.plugin.api;
    requires javafaker;


    opens org.example.javaFX;
}